package method_ReferencingAnd_Streams;

@FunctionalInterface 
	interface Display 
	{  
		void display();  
	} 

	public class Method_ref
	{  
	    public static void sum() //static method 
	    {  
	    int a = 10;
	    int b= 5; int c;
	    c = (a+b);
		System.out.println("sum of a & b is: " + c);  
    }  
    
     Method_ref() // Constructor
      {
        System.out.println("How to invoke constructor call using method references");
      }
    
    
    public static void main(String[] args) {  
    Display obj = Method_ref::sum;
    obj.display();
	obj = Method_ref::new;
	obj.display();
    }  
}
