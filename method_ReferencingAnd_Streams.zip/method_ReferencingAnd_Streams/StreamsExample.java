package method_ReferencingAnd_Streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Students
	{
	int Roll_no;
	String Name;
	String Address;
	
	public Students(int Roll_no, String Name, String Address)
	{
	this.Roll_no = Roll_no;
	this.Name = Name;
	this.Address = Address;
	}
	}
public class StreamsExample 
{

	public static void main(String[] args) 
	{
		List<Students> students_list = new ArrayList<Students>();
		students_list.add(new Students(001, "Anandh", "Chennai"));
		students_list.add(new Students(002, "Hema", "Chennai"));
		students_list.add(new Students(003, "Priya", "Bangalore"));
		students_list.add(new Students(004, "Aanandh", "Cochin"));
		students_list.add(new Students(005, "Imran", "Bangalore"));
		
		//iterate using for each
		Stream<Students> streamstudents = students_list.stream();
		streamstudents.forEach((Students)->
		{
			System.out.println("Student Details" + '\n' + "Roll_No:"+Students.Roll_no + '\n' + "Name:"+Students.Name + '\n' + "Address: "+Students.Address);
		});
		
		//count method
		streamstudents = students_list.stream();
		System.out.println("Total number of students:" + streamstudents.count());
		
		//filter 
		streamstudents = students_list.stream();
		streamstudents.filter((s)-> s.Address == "Chennai").forEach((p)->System.out.print("Students whose city is Chennai: " + '\n' + p.Name + " " + '\n'));
		
		//distinct method
		List<Students> distinctElements = students_list.stream().distinct()
											.collect(Collectors.toList());
		System.out.println(distinctElements);
		
		
		
			
	}

}
	
